<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        return isset($_GET['phpinfo']) ? phpinfo(): view('welcome_message');
    }

}
