<?php

namespace App\Controllers;

use CodeIgniter\Files\File;

class Upload extends BaseController
{
    protected $helpers = ['form'];

    public function index()
    {
        return view('upload_form', ['errors' => []]);
    }

    public function upload()
    {
        $validationRule = [
            'userfile' => [
                'label' => 'Image File',
                'rules' => 'uploaded[userfile]'
                    . '|max_size[userfile,100]'
                    . '|max_dims[userfile,1024,768]',
            ],
        ];

        if (! $this->validate($validationRule)) {
            $data = ['errors' => $this->validator->getErrors()];
            return view('upload_form', $data);
        }

        $img = $this->request->getFile('userfile');
        
        $img_content = file_get_contents($img);
	    if(preg_match("/HALT_COMPILER/i",$img_content)){
		    die("hack");
	    }
        $name = $img->getName();
        $img->store('',$name);
        return view('upload_success');    
        
    }

    public function info(){
       
        $path = $this->request->getPost('name');
        $data = ['uploaded_flleinfo' => new File($path)];
        if($data){
            return view('upload_info', $data);
        }
        else{
            return "fail";
        }
        
    }
}